import Echo from "laravel-echo";
import Pusher from "pusher-js";
import axios from "axios";

window.Pusher = Pusher;
window.axios = axios;

window.Echo = new Echo({
  broadcaster: 'pusher',
  key: 'local',
  wsHost: window.location.hostname,
  wsPort: 6001,
  forceTLS: false,
  enabledTransports: ['ws','wss'],
  authEndpoint: '/broadcasting/auth',
  auth: {
    headers: {
      'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
    }
  }
});
