<!doctype html>
<html>
<head>
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>Call Demo</title>
  <style>
    body{font-family: Arial, Helvetica, sans-serif; padding:20px;}
    video{border:1px solid #ccc; display:block; margin-bottom:10px;}
  </style>
</head>
<body>
  <h2>Laravel WebRTC Call Demo</h2>
  <p>Logged in as: {{ auth()->user()->email ?? 'user' }} (ID: {{ auth()->id() }})</p>

  <video id="localVideo" autoplay muted playsinline width="320" height="240"></video>
  <video id="remoteVideo" autoplay playsinline width="640" height="480"></video>

  <div>
    <input id="target" placeholder="Target user id (e.g., 2)">
    <button id="callBtn">Call</button>
  </div>

  <script>window.USER_ID = {{ auth()->id() }};</script>
  <script type="module" src="/resources/js/call.js"></script>
</body>
</html>
