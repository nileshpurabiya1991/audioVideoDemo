<!doctype html>
<html>
  <head><title>Welcome</title></head>
  <body>
    <h1>Laravel Call Demo Skeleton</h1>
    <p><a href="/call">Go to call page (requires login)</a></p>
  </body>
</html>
