# Laravel 11 Audio/Video Call Demo (Skeleton)

This is a **skeleton** Laravel 11 demo project for **Audio/Video calling** using **WebRTC** (browser peer-to-peer) and **Laravel WebSockets** (BeyondCode) for signaling.

IMPORTANT: This repository is a skeleton — you must run `composer install`, `npm install`, and other steps locally.

## Quick setup

1. Extract the ZIP.
2. Copy `.env.example` to `.env` and edit if needed.
3. Run:
   ```bash
   composer install
   npm install
   cp .env.example .env
   php artisan key:generate
   php artisan migrate
   npm run dev   # or npm run build/vite build depending on your setup
   php artisan serve --host=127.0.0.1 --port=8000
   php artisan websockets:serve
   ```
4. Register two users (open normal + incognito).
5. Visit `/call`, enter the other user's ID and click **Call**.

## Notes
- Local demo works on `localhost`/`127.0.0.1` without TURN or HTTPS.
- For production or remote demos you need HTTPS (wss) and a TURN server.
- This skeleton omits vendor/ node_modules. It is ready to `composer install` and `npm install` locally.
