<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Events\CallOffer;
use App\Events\CallAnswer;
use App\Events\IceCandidate;

class CallController extends Controller
{
    public function sendOffer(Request $req)
    {
        $req->validate(['to' => 'required|integer', 'offer' => 'required']);
        event(new CallOffer(auth()->id(), $req->to, $req->offer));
        return response()->json(['ok' => true]);
    }

    public function sendAnswer(Request $req)
    {
        $req->validate(['to' => 'required|integer', 'answer' => 'required']);
        event(new CallAnswer(auth()->id(), $req->to, $req->answer));
        return response()->json(['ok' => true]);
    }

    public function sendIce(Request $req)
    {
        $req->validate(['to' => 'required|integer', 'candidate' => 'required']);
        event(new IceCandidate(auth()->id(), $req->to, $req->candidate));
        return response()->json(['ok' => true]);
    }
}
