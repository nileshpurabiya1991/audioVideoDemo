<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CallController;

Route::get('/', function () { return view('welcome'); });

Route::middleware('auth')->get('/call', function() {
    return view('call');
});

Route::middleware('auth')->post('/call/offer', [CallController::class,'sendOffer']);
Route::middleware('auth')->post('/call/answer', [CallController::class,'sendAnswer']);
Route::middleware('auth')->post('/call/ice', [CallController::class,'sendIce']);
